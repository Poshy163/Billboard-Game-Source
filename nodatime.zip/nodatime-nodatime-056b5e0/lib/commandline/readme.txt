The Command Line Parser Library is hosted at
https://github.com/gsscoder/commandline

We build the source files into NodaTime.TzdbCompiler, to avoid requiring a
strongly-named copy of the assembly. Please see the LICENSE file
for further information. We don't anticipate any need to keep this
library particularly up-to-date, and it's not currently included in the
binaries distributed with Noda Time.

Modification
------------

This copy of the library has been modified to be compatible with
.NET Core.